import { combineReducers } from 'redux';

export default combineReducers({
	// exportamos todos los reducer de la aplicacion
	deportes: () => []
});